def Init_board():                               #?????
    global board
    board = [[0] * l for row in range(l)]       #????????????????,?????,?0?????,1????,-1????
    board[int(l / 2 - 1)][int(l / 2 - 1)] = -1
    board[int(l / 2 - 1)][int(l / 2)] = 1
    board[int(l / 2)][int(l / 2 - 1)] = 1
    board[int(l / 2)][int(l / 2)] = -1          #?????????
    return board


def printBoard():                               #????
    l = len(board)                              #????????????
    print(' ', end = ' ')                  
    for i in range(l):
        print(chr(ord('a') + i), end = ' ')     #?ASCII????????????
    print()
    for i in range(l):
        print(chr(ord('a') + i), end = ' ')     #???????
        for j in range(l):
            if (board[i][j] == 0):
                print('.', end = ' ')
            elif (board[i][j] == 1):
                print('X', end = ' ')
            else:
                print('O', end = ' ')           #?????????
        print()


def computer_move(row, col, color):             #?????????
    global board
    if (check != 0):                            #check???????????(??????),??0???
        board[row][col] = color                 #?????????
        direction = ((-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1))
        for i in range(8):
            z = 1                               #?8???????
            while (0<= row + (z+1) * direction[i][0] < l) and (0<= col + (z+1) * direction[i][1] < l) and (
                board[row + z * direction[i][0]][col + z * direction[i][1]] == -color):#???????,????????????????(????????????????????),????????????????
                z += 1                                                                 #???????????python??????-1??,???????????????0,???????????????(???-1)??
                if board[row + z * direction[i][0]][col + z * direction[i][1]] == color: #???????????????
                    for j in range(z):
                        board[row + j * direction[i][0]][col + j * direction[i][1]] = color #?????????????????????
                    break                  


def human_move(row, col, color):                #?????????,???????
    global board
    if (check != 0):
        board[row][col] = color
        direction = ((-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1))
        for i in range(8):
            z = 1
            while (0<=row + (z+1) * direction[i][0] < l) and (0 <= col + (z+1) * direction[i][1] < l) and (
                board[row + z * direction[i][0]][col + z * direction[i][1]] == -color):
                z += 1
                if board[row + z * direction[i][0]][col + z * direction[i][1]] == color:
                    for j in range(z):
                        board[row + j * direction[i][0]][col + j * direction[i][1]] = color
                    break


def check_board():                               #??????????
    a1 = 1                                       #??????????
    a21 = 1                                      #???????????
    a22 = 1                                      #???????????
    a4 = 0                                       #????????????
    for i in range(l):
        for j in range(l):                       #??????
            if (board[i][j] == 0):                #??????
                a1 = 0
            elif (board[i][j] == 1):              #??????
                a21 = 0
            else:                                 #??????
                a22 = 0

    if not (check):                               # check?0??????,????
        a4 = 1
    if (a1 or (a21 and a22) or (not (xp or op)) or a4):
        if (a1 or (a21 and a22) or (not (xp or op))):     # xp?op?????????????
            if (not (xp or op)):                          #????0,???????????
                print("Both player have no vaild move!")
            gameover('score')                             #????????????

        else:                                             #??a4???,?????,??????
            gameover('illegal')


def check_legal_move(row, col, color):          #??????????
    direction = ((-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1))
    score = 0

    for i in range(8):                                    #??????????,???????????????????,???????????? 
        zscore = 1
        while (0 <= (row + (zscore+1) * direction[i][0]) < l) and (0 <= (col + (zscore+1) * direction[i][1]) < l) and (
                (board[row + zscore * direction[i][0]][col + zscore * direction[i][1]]) == -color):
            if (board[row + (zscore + 1) * direction[i][0]][col + (zscore + 1) * direction[i][1]] == color):
                score += zscore
                break
            zscore += 1
    return score


def gameover(s):                                          #??????
    global s1
    global condition
    global black
    global white

    condition = 0                                         #??????? 0,????
    if s == 'score':                                      #???????,?????????
        print('Game Over!')
        black = 0
        white = 0

        for i in range(l):
            for j in range(l):
                if board[i][j] == 1:
                    black += 1
                if board[i][j] == -1:
                    white += 1
        if (black > white):
            print('X : O =', black, ':', white)
            print('X player wins!')
        elif (black < white):
            print('O player wins!')
            print('X : O =', black, ':', white)
        else:
            print('Draw!')
        s1 = str(black) + 'to' + str(white)              # s1 ??????????????
        return s1
    if s == 'illegal':
        print('Invaild move!')
        s1 = 'Invaild move!'
    if s == 'gg':
        print('Human gave up!')
        s1 = 'Human gave up!'
    print('Game Over!')
    if (color == 1):                                      #????????gg???????,color???????
        print('O player wins.')
    else:
        print('X player wins.')
    return s1


def saveinfo():                                            #????
    time3 = time.time()                                    #??????
    long = time3-time2                                     #??????
    f = open('Reversi.csv', 'a+')
    s = str(time1) + ',' + str(long) + ',' + str(l) + '*' + str(l) + ',' + Xplayer + ',' + Oplayer + ',' + s1
    f.write(s)                                             #??????
    f.write('\n')
    f.close()


import datetime
import time

time1 = datetime.datetime.now().strftime('%Y-%m-%d %T')  # 保存游戏时间
time2 = time.time()  # 游戏开始时间
l = int(input('Enter the board dimension：'))  # l 中保存了棋盘的长度
board = Init_board()  # 初始化棋盘
x1 = input('Computer plays (X/O):')  # x1中保存电脑的棋子颜色
if (x1 == 'X'):  # 电脑执黑
    hcolor = -1
    Xplayer = 'computer'
    Oplayer = 'human'  # 这个是要输进文件里的东西
    condition = 1  # 游戏标记置1，游戏进行

    printBoard()  # 打印 、
    while condition:  # 如果游戏标志为1（没进gameover），则可以继续运行
        legal = []
        for i in range(l):
            for j in range(l):
                if (board[i][j] == 0):
                    if (check_legal_move(i, j, 1) != 0):
                        legal.append([i, j, check_legal_move(i, j, 1)])  # 将所有可下位置存进legal列表中
            legal.sort(key=lambda x: x[1], reverse=False)
        legal.sort(key=lambda x: x[0], reverse=False)
        legal.sort(key=lambda x: x[2], reverse=True)  # 对列表进行先值，再行，再列的排序
        if (legal != []):  # 如果存在合法输入
            row = legal[0][0]
            col = legal[0][1]
            color = 1
            check = check_legal_move(row, col, color)
            xp = 1  # 证明X仍可下
            op = 1  # 证明O仍可下
            computer_move(row, col, 1)  # 将分值存进check里，进行落子
            print('Computer places X at', chr(ord('a') + row), chr(ord('a') + col), '.')
        else:
            xp = 0  # 如果不存在落子位置
            print('X player has no vaild move.')  # 不进行落子

        printBoard()  # 进行棋盘打印
        check_board()  # 进行检测棋局是否结束
        if (condition != 0):  # 如果棋局没有结束的话进行人类行棋
            legal = []
            for i in range(l):
                for j in range(l):
                    if board[i][j] == 0:
                        if (check_legal_move(i, j, -1) != 0) and (board[i][j] == 0):
                            legal.append([i, j, check_legal_move(i, j, -1)])  # 检测是否有行棋位置
            if (legal != []):
                inter = input('Enter move for O (Rowcol):')
                if inter == 'gg':  # 贴心的投降设置
                    gameover('gg')
                    break
                row = ord(inter[0]) - 97  # 把输入的字母通过ASCII码变成输出
                col = ord(inter[1]) - 97
                color = -1
                if (row >= l) or (col >= l) or (row < 0) or (col < 0):  # 如果输入超过边界，则为非法输入
                    gameover('illegal')
                    break

                check = check_legal_move(row, col, color)  # 检测落子是否存在翻转
                xp = 1
                op = 1
                human_move(ord(inter[0]) - 97, ord(inter[1]) - 97, -1)  # 人类落子
                check_board()  # 检测当前棋盘是否满足结束条件
                if check:
                    printBoard()  # 如果通过，则进行打印
            else:
                op = 0  # 白棋无棋可下
                print("O player has no vaild move.")
    saveinfo()  # 游戏结束之后进行游戏记录的保存


else:  # 之后为电脑执白棋的情况，与上文黑棋的情况类似
    hcolor = 1
    Oplayer = 'computer'
    Xplayer = 'human'
    condition = 1

    printBoard()
    while condition:
        legal = []
        for i in range(l):
            for j in range(l):
                if (board[i][j] == 0):
                    if (check_legal_move(i, j, 1) != 0):
                        legal.append([i, j, check_legal_move(i, j, 1)])
        if (legal != []):
            inter = input('Enter move for X (Rowcol):')
        if inter == 'gg':
            gameover('gg')
            break

        row = ord(inter[0]) - 97
        col = ord(inter[1]) - 97
        color = 1
        if (row >= l) or (col >= l) or (row < 0) or (col < 0):
            gameover('illegal')
            break

        check = check_legal_move(row, col, color)
        xp = 1
        op = 1
        human_move(ord(inter[0]) - 97, ord(inter[1]) - 97, 1)
        check_board()
        if check:
            printBoard()
    else:
        op = 0
        print("O player has no vaild move.")

    if condition:
        legal = []
        for i in range(l):
            for j in range(l):
                if (board[i][j] == 0):
                    if (check_legal_move(i, j, -1) != 0):
                        legal.append([i, j, check_legal_move(i, j, -1)])
        legal.sort(key=lambda x: x[1], reverse=False)
        legal.sort(key=lambda x: x[0], reverse=False)
        legal.sort(key=lambda x: x[2], reverse=True)
        if (legal != []):
            xp = 1
            op = 1
            row = legal[0][0]
            col = legal[0][1]
            color = -1
            check = check_legal_move(row, col, color)
            computer_move(row, col, -1)
        else:
            xp = 0
            print("X player has no vaild move.")
        check_board()
        printBoard()
        print('Computer places O at', chr(ord('a') + row), chr(ord('a') + col), '.')

saveinfo()

                    
                    
                    
                
                
            
