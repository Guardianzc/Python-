import time
import random

def choose():
    global nwords                                                   #全局变量模块
    global plines
    global cwords
    global n
    global guess
    global begintime,btime
                                                                    #时间模块
    begintime = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime())     #显示游戏开始的时间
    btime = time.clock()                                                #同样的显示游戏开始的时间（为了计算游戏时长）
    
    c = random.randint(0,lenwords)                                  #产生随机单词模块
    cwords = words[c]                                                   #选择随机单词
    nwords = len(words[c])                                              #得出随机单词的长度（为了得出空格的个数）

                                                                    #初始化模块
    plines = ['_' for i in range(nwords)]                               #pline这里是猜词的列表，也是显示出来的列表
    n = 0                                                               #n为错误的个数
    guess = ''                                                          #guess为猜词的历史记录
    writetable(n)                                                       #最初的writetable（输出界面显示）

    while n != 6:                                                   #猜词判断模块
        r = input('Please input: ')                                     #r为用户猜测的字符

        if r == 'cheat':                                                #作弊码——为了调试的时候能直接看到猜测的单词写的作弊码（直接输入cheat可以看到单词）
            print(cwords)
            
        bc = 0                                                          #bc是一个判断标记，1——猜词正确
        
        guess = guess + r                                               #将猜的词添加到历史记录里

        for i in range(nwords):                                     #替换模块                                          
            if r == cwords[i]:                                          #如果检测到匹配，就把匹配到的i位置相同位置的pline中'_'也替换为该字母
                plines[i] = r
                bc = 1                                                  #标记到匹配
                                                                    
                                                                    #游戏结束检测模块
        guessw = ''                                                     #guessw是为了将pline中的字符合并，与原单词匹配
        for i in plines:
            guessw = guessw + i
        if guessw == cwords:
            writetable(n,bb = 1)                                        #bb = 1标记为成功结束游戏
            return                                                      #这里递归回来之后要return出去不能再往下走了（这个函数要结束掉）
        
        if bc:                                                      #导出到输出模块，错误次数n不变（这里pline变了）
            writetable(n)
        else:
            n += 1
            writetable(n)                                           #猜错了也错误次数+1进入输出模块 

    return                                                          #程序结束

def writetable(n,bb = 0):                                           #输出界面（n为错误次数，bb标记游戏是否成功）
    print('mistakes : ',n)                                              #输出错误次数
    s = ''                                                              #s 这里为绞刑架左边的部分
    if bb == 1:                                                         #如果游戏成功则s输入为“YOU WIN！”
        s = 'YOU WIN!'
    if n != 6:                                                          #错误次数小于6
        if bb == 0:                                                     #如果游戏还没结束则s里面输入的是pline的字符
            s = ''
            for i in range(nwords):
                s = s + plines[i] + ' '
            
        if n == 0:                                                      #按照错误次数n不同输出不同的格式（format）,这样分行输出很不专业...但是没找到单行输出多行数据的方法
            print(' '*30,' ______')
            print(' '*30,'|  |')
            print(' '*30,'|  ')
            print(' '*30,'| ')
            print(' '*30,'| ') 
            print('{:^30}'.format(s),'|  ')
            print(' '*30,'|_____')
            print(' '*30,'|     |____')
            print(' '*30,'|__________|')

        elif n == 1:
            print(' '*30,' ______')
            print(' '*30,'|  |')
            print(' '*30,'|  O')
            print(' '*30,'| ')
            print(' '*30,'|  ')
            print('{:^30}'.format(s),'| ')
            print(' '*30,'|_____')
            print(' '*30,'|     |____')
            print(' '*30,'|__________|')

        elif n == 2:
            print(' '*30,' ______')
            print(' '*30,'|  |')
            print(' '*30,'|  O')
            print(' '*30,'| / ')
            print(' '*30,'|  ')
            print('{:^30}'.format(s),'| ')
            print(' '*30,'|_____')
            print(' '*30,'|     |____')
            print(' '*30,'|__________|')
            
        elif n == 3:
            print(' '*30,' ______')
            print(' '*30,'|  |')
            print(' '*30,'|  O')
            print(' '*30,'| /|')
            print(' '*30,'|  |')
            print('{:^30}'.format(s),'| ') 
            print(' '*30,'|_____')
            print(' '*30,'|     |____')
            print(' '*30,'|__________|')

        elif n == 4:
            print(' '*30,' ______')
            print(' '*30,'|  |')
            print(' '*30,'|  O')
            print(' '*30,'| /|\ ') 
            print(' '*30,'|  | ')
            print('{:^30}'.format(s),'| ')
            print(' '*30,'|_____')
            print(' '*30,'|     |____')
            print(' '*30,'|__________|')

        elif n == 5:
            print(' '*30,' ______')
            print(' '*30,'|  |')
            print(' '*30,'|  O')
            print(' '*30,'| /|\ ' ) 
            print(' '*30,'|  | ')
            print('{:^30}'.format(s),'| /  ')
            print(' '*30,'|_____')
            print(' '*30,'|     |____')
            print(' '*30,'|__________|')

        else:
            s = 'YOU LOSE!'
            print(' '*30,' ______')
            print(' '*30,'|  |')
            print(' '*30,'|  O')
            print(' '*30,'| /|\ ')
            print(' '*30,'|  | ')
            print('{:^30}'.format(s),'| / \ ')
            print(' '*30,'|_____')
            print(' '*30,'|     |____')
            print(' '*30,'|__________|')
        print()                                                         #在最后输出一行空行，将其与下一层输入分隔开 
            
    if bb or n == 6:                                                    #这里是游戏结束之后的那一行输出
        print('The secret word is %s, you guess via %s.And YOU '%(cwords,guess),end = '')
        if bb:
            print('WIN!')
        else:
           print('LOSE!')
        continued()                                                     #进入询问游戏是否继续下一轮模块
    return

def continued():                                                    #下一轮游戏是否继续的判断模块
    etime = time.clock()                                                #这轮游戏的结束时间（计算游戏时长） 
    handler = open('guess.csv','a+')                                    #打开文件（指针a+附到文件末尾写入）
    write = ''
    write = begintime + ',' + str(etime - btime) + ',' + cwords + ',' + guess #要写入的所有信息（以逗号分隔）
    try:
        handler.write(write)                                               
        handler.write('\n')                                             #写入一行空行使每一轮游戏在不同的行
    finally:
        handler.close()
    
    con = input('Continue game(C[c]Qq)?')                           #询问模块    
    if (con == 'q') or (con == 'Q'):
        print('Bye... Game over!!!')
        return                                                          #return退出到上一个栈
    else:
        choose()                                                        #继续则跳回到选词模块里
        return                                                          #退到上一层
    
longstr = ''                                                        #主程序模块  
handler = open('words.txt')                                             #打开文件
try:
    lines = handler.readlines()
finally:
    handler.close()
for i in range(len(lines)):                                             #把每一行的词写到同一行里
    longstr = longstr + lines[i] + ' '

words = longstr.split(' ')                                              #分隔开成为列表
lenwords = len(words) - 2                                               #统计总词的个数（后面随机的上限，因为有个空元素并且随机从0开始所以 -2）
choose()                                                                #选词模块

