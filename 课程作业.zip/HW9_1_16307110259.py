import re

s = input('Please enter an English paragraph: ')

pattern = re.compile(r'\b[a-zA-Z]{3}\b')     #匹配三个字母的结果
print(pattern.findall(s))
