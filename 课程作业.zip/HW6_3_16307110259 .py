from math import sqrt 
print('Enter the coordinates of 3 points:')
length = []
flag = 1                                        #初始设置

a = eval(input('1st point: '))
b = eval(input('2nd point: '))
c = eval(input('3rd point: '))

ab = sqrt((a[0] - b[0])**2 + (a[1] - b[1])**2) 
bc = sqrt((b[0] - c[0])**2 + (b[1] - c[1])**2)
ac = sqrt((a[0] - c[0])**2 + (a[1] - c[1])**2)


length.append(ab)
length.append(bc)
length.append(ac)                              #输入三个点，计算三边长
length.sort()                                  #为方便数据处理先排序

if abs(length[0] + length[1] - length[2]) < 1e-6: 
    print('Three points are collinear, which can not form a triangle') #判断1：是否能构成三角形

else:
    if abs(length[1] - length[0]) <1e-6 and abs(length[2] - length[1]) <1e-6:
        print('A equilateral',end='')
        flag = 0
    else:
        if abs(length[1] - length[0]) <1e-6 or abs(length[2] - length[1]) <1e-6:
            print('An isosceles',end='')
            flag = 0                                                   #判断2：是否为等边（如否，则是否为等腰）三角形，同时处理A，An的问题
    if abs(length[0]**2+length[1]**2-length[2]**2) < 1e-6:             #判断3：判断是否为直角三角形
        if flag:
            print('A right',end = '')
            flag = 0
        else:
            print(' right',end = '')
            flag = 0                                                   #通过flag判断是否需要加上开头的A
    if flag:
        print('A triangle.')                                           #如flag = 1，则证明是普通三角形
    else:
        print(' triangle.' )                                           #flag = 0，则添加一个标准输出的结尾

