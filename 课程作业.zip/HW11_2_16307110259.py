import random
def arrange(a,x):
    '''对输入的列表以x为锚重排'''
    b = []
    b.append(x)                                     #先输入x
    pointer = 0                                     #指针初始化（指向小数的插入位置）
    for i in range(len(a)):
        if a[i] != x:
            if a[i] < x:
                b.insert(pointer,a[i])
                pointer += 1                        #如小于，则将其插入指针位置，指针向后推一项仍指向n
            else:
                b.append(a[i])                      #大于则直接排在末尾
    return b
 
 
a = random.sample(range(1,100),15)                  #产生不重复的随机数列
n = a[7]
print('Before the arrangement, the data is:')
print(a)
print('n:',n)
print('After the arrangement, the data is:')
print(arrange(a,n))                                 #输出过程
