import math

r = float(input('Radius?'))#输入并转换为浮点数

area = math.pi*r**2        #计算面积
length = len(str(int(area)))#取整并转换为字符串计算长度

print('Area:',area)
print('Its integral part is a %d-digit number'%length)
