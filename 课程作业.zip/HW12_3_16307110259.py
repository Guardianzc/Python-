def sanitize(time_string):
    time_string = time_string.replace(':','.')
    time_string = time_string.replace('-','.')
    return time_string                                 #用replace重写时间格式

def get_coach_data(filename):
    try:
        file = open(filename)
    except BaseException:
        print('File error: [Errno 2] No such file or directory: %s ' %(filename))
    else:                                           #判断是否能打开文件
        line = file.readlines()
        file.close()
        f = line[0]
        f = f.split(',')
        del f[0]
        del f[0]                                   #用,分割字符串并删除前面的名字和时间
        l = len(f)

        for i in range(l):
            f[i] = float(sanitize(f[i]))           
        f = list(set(f))                           #重写时间格式并去重
        f.sort()
        a = []

        for i in range(3):
            a.append(str(f[i]))                    #排序并返回前三的值
        return a

print('James Lee\'s fastest times are:',get_coach_data('james.txt'))
print('Julie Jones\'s fastest times are:',get_coach_data('julie.txt'))        
print('Mikey McManus\'s fastest times are:',get_coach_data('mikey.txt'))        
print('Sarah Sweeney\'s fastest times are:',get_coach_data('sarah.txt'))        
