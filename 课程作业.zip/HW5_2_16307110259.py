import random
x = [random.randint(0,100) for i in range(20)]
print('The original integer list is: ')
print(x)
y = x[::2]                        #切片提取出偶数下标
y.sort(reverse=True)
x[::2] = y                        #排序并替代原有下标
print('After sorting the elements with even index in descending order:')
print(x)
