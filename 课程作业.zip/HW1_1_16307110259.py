x=int(input('请输入一个三位数'))
hundred=x//100
ten=x//10%10
unit=x%10
print(hundred,ten,unit)

