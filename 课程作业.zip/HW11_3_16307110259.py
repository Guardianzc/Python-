def judge(fname):
    '''从文件名判断文件是.py还是.cpp'''
    with open(fname,'r') as f:
        name = f.name
    name = name.split('.')
    if name[1] == 'py':
        bb = 1
    else:
        bb = 0
    return bb

def comment(fname,clear):
    '''处理不同类型的文件'''
    with open(fname,'r') as f:
        lines = f.readlines()
    linenum = 1

    if clear:
        for line in lines:
            if not(line.startswith('#')):           
                line = [ str(linenum)+')'+line]
                linenum += 1
                print(line)
                print
        print(lines)
        with open(fname[:-3]+'_n.py','w') as f:
            f.writelines(lines)
        
         
    else:
        for line in lines:              
            if not(line.startswith('//')): 
                line = [ str(linenum)+')'+line]
                linenum += 1
                print(line)
        print(lines)
        with open(fname[:-4]+'_n.cpp','w') as f:
            f.writelines(lines)
       

comment('property.py',judge('property.py'))

