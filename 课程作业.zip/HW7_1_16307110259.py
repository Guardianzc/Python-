n = int(input('请输入n：'))

for i in range(1,n+1):
    s = ' ' * (2 * (n + 1 - i)) + '* ' * (2 * i - 1)
    print(s)
                                                    #上半部分图形
print('* ' * (2*n+1))                               #中间一行

for i in range(n,0,-1):
    s = ' ' * (2 * (n + 1 - i)) + '* ' * (2 * i - 1) 
    print(s)                                        #下半部分图形
