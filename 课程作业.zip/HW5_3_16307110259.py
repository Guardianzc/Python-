import math
print('The first method: list comprehension')
a = [p for p in range(2,100) if 0 not in [p % d for d in range(2,int(math.sqrt(p))+1)]] #列表推导式创建素数列表
print('The odd numbers under 100 are:',a)
print('Their sum is:',sum(a))

print('The second method: loop code')
b = []
for i in range(2,101):                              #需要查询的数的范围
    flag = 1                                        #设立一个标记
    for j in range(2,int(math.sqrt(i))+1):
        if i % j ==0:
            flag = 0                                #如其符合合数的要求，则改变标记的值
    if flag:
        b.append(i)                                 #如为质数则添加进列表内
print('The odd numbers under 100 are:',b)
print('Their sum is:',sum(b))
