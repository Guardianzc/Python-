print('Introduction: Please guess a number between 1 and 100. You have 5 chances.')
print()

from random import randint
res = randint(1,100)                                    #产生最初的随机数

def guess(res):
    if times == 0:                                      #最后一次判断
        if num == res:
            print('Yeah!:D')
            return
        elif num < res:
            print('Smaller.',times,' chances left.')
            print('Oops...Good luck next time!')
        else:
            print('Bigger.',times,' chances left.')
            print('Oops...Good luck next time!')

    else:
        if num == res:                                 #仍有机会时的判断
            print('Yeah!:D')
            return
        elif num < res:
            print('Smaller.',times,' chances left.')
        else:
            print('Bigger.',times,' chances left.')

for times in range(4,-1,-1):                           #从4-0按次数循环判断
    num = int(input('Guess: '))
    guess(res)                                         #然而猜不对也并不会告诉你答案的lol
    print(res)        
