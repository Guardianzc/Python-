import random

l = [random.randint(0,100) for i in range(1000)]

print('The random list is:')
print(l)                      #产生随机数列表并输出

l.sort()                      #先对随机数列表进行排序，这样字典中的key是升序的

d = dict()
for ch in l:
    d[ch] = d.get(ch,0) + 1   #产生出现次数的字典

d = sorted(d.items(),key=lambda k:k[1]) #对字典的value进行排序

print('The statistical result is:')  
print(d)                      #输出
 
