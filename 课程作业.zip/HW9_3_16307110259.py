import re
s = input('Enter a string: ')

m = re.compile(r'<[^>]*>')         #匹配‘<>’内的字符

final = m.sub('',s)                #将其替换为‘’（删去）

print(final)
