flag = 1
while flag:
    s = int(input('Enter an integer(<1000):'))                                     
    if 0 < s < 1000:
        flag = 0                          #输入处理
        
final = s
ys = []                                   #创建质因数数组    

for i in range(s):
    for j in range(2,s):                  #搜索质因数
        if s % j == 0:
            ys.append(j)
            s = s // j
            break                         #寻找到最小的因数之后马上退出
ys.append(s)                              #最后留下的s也是质因数  
 
print('%d = %d'%(final,ys[0]),end='')
for i in range(1,len(ys)):
    print('*%d'%ys[i],end='')             #标准化输出 
