aList = list(eval(input('Enter some integers (separated by comma):')))
print('The list is:',aList)

begin,end = eval(input('Enter 2 integers (separated by comma):'))
print('The slice of the list is:',aList[begin:end])#切片输出
                    
                 
