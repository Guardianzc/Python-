import pickle
n = 1                                                    #只输入一个数据
grades = {'Russel':[72,87,88,54,55,82,69,87],
          'Thomas': [90,96,99,99,100,81,97,97],
          'Vaughn': [81,97,99,67,40,90,70,96],
          'Westerly': [43,98,96,79,100,82,97,96]}

f = open('Grade.dat','wb')                  
try:
    pickle.dump(n, f)
    pickle.dump(grades, f)                              #尝试输入

except BaseException:
    print('输入异常！')                                 #返回异常值

finally:
    f.close()

'''
读取二进制内容
'''

f = open('Grade.dat','rb')
n = pickle.load(f)
for i in range(n):
    x=pickle.load(f)
    try:
        print(x)                                        #尝试输出
    except BaseException:
        print('输入异常！')
    
f.close()
