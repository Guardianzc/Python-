n = input('Enter n:')
n = int(n)
list = [[] for i in range(n)]
                                       #初始化二维数组
count = 1
for i in range(1,n+1):
    if i % 2 == 1:
        for j in range(0,i):
            list[j].append(count)
            count += 1
            
    else:
        for j in range(i-1,-1,-1):
            list[j].append(count)
            count += 1
                                       #根据行数奇偶不同先画出半个正方形


for i in range(n-1,0,-1):
    if i % 2 == 1:
        for j in range(n-i,n):
            list[j].append(count)
            count += 1
            
    else:
        for j in range(n-1,n-i-1,-1):
            list[j].append(count)
            count += 1
                                        #逆序画出下半个三角形

for i in range(n):
    for j in range(n):
        print('%4d' %list[i][j],' ',end=' ')
    print()
                                        #对齐输出
