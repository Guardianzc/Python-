def Perfect(num,b = 0):
    '''判断完美数，如是则返回1，否则返回0'''
    counts = 0
    for i in range(1,num):
        if num % i == 0:
            counts += i
    if counts == num:
        b = 1
    return b                                      #判断完美数，如是则返回1，否则返回0

print('The perfect numbers less than 1000 are:')
for j in range(1,1001):
    if Perfect(j):
        print(j,end=" ")                          #循环调用判断程序，符合条件则输出
