import tkinter
import tkinter.ttk
from tkinter import END, StringVar
def cal(event):
    global c
    dic = {0:160, 1:130, 2:60}
    c = dic[combox.current()]                                               #多选框参数设置

    
        
def calculate():
    result.delete(0.0,END)
    dic1 = {0:1,1:2,2:3,3:20,4:50,5:E_text.get()}
    d = int(dic1.get(var1.get()))
    if d < 20:
        write = str(c) + '*' + str(d) + '=' + str(c*d)
        result.insert(0.0,write)
    elif 20<= d <50:
        write = str(c) + '*' + str(d) + '*0.95' + '=' + str(c*d*0.95)
        result.insert(0.0,write)
    elif d >= 50:
        write = str(c) + '*' + str(d) + '*0.8' + '=' + str(c*d*0.8)
        result.insert(0.0,write)
    result.insert(0.0,'\n')
    result.insert(0.0,'总票价为：')                                       #提取单选框的数据做计算
        
root = tkinter.Tk()
root.title('景点购票窗口')
root.geometry('420x360')                                                  #主窗体

var = tkinter.StringVar()
var1 = tkinter.IntVar()
E_text = tkinter.StringVar()
lb1 = tkinter.Label(root,text='请选择景点')
lb1.place(x=60,y=40,height=40,width=80)                                   #多选框文本label设置

lb2 = tkinter.Label(root,text='请选择购票张数')
lb2.place(x=200,y=40,height=40,width=100)

btn1 = tkinter.Button(root,text = '确认', command = calculate)            #确认按钮设置
btn1.place(x=225,y=180,height=25,width=50)

E = tkinter.Entry(root,textvariable = E_text)                             #自由输入的输入框设置
E.place(x=330,y=130,width=80)

btnclose = tkinter.Button(root,text = '取消', command = root.destroy)     #取消按钮设置
btnclose.place(relx=0.4,rely=0.9,height=25,width=50)

combox = tkinter.ttk.Combobox(root,textvariable=var,
                              values=('东方明珠','野生动物园','科技馆'))  #多选按钮设置
combox.place(x=60,y=80,width=90)
combox.bind('<<ComboboxSelected>>',cal)

txt = ('1张','2张','3张','20张','50张','自行输入')                        #分两行设置单选按钮
for i in range(3):
    radioBtn = tkinter.Radiobutton(root,text=txt[i],variable=var1,
                                   value = i)
    radioBtn.place(x=200,y=70+i*30)

for i in range(3,6):
    radioBtn = tkinter.Radiobutton(root,text=txt[i],variable=var1,
                                   value = i)
    radioBtn.place(x=250,y=i*30-20)

result = tkinter.Text(root,font = 'cambria')                               #输出文本框设置
result.place(relx=0.1,rely = 0.6,relheight = 0.25, relwidth = 0.8 )

root.mainloop()
