name = input('Enter your name:')

wel = 'Hi, '+name+'!'#将名字换为欢迎语
length = len(wel)+4  #计算每行长度

a = '*'* length                     #第一，第五行
b = '*' + ' ' * (length - 2) +  '*' #第二，第四行
c = '*' + ' ' + wel + ' ' + '*'     #第三行

print(a,b,c,b,a,sep='\n')
