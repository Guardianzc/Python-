import random

a = [random.randint(1,100) for i in range(10)]#生成随机数

print('10 random integers:', a)
print('The max is:', max(a))
print('The min is:', min(a))
print('The average is:', sum(a) / len(a))
