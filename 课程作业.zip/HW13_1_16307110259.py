def inputpart():
    '''输入部分'''
    raw = input('Please enter range[a,b](0<a<=b): ')
    raw = raw.replace(' ',',')
    raw = raw.replace('-',',')
    raw = raw.split(',')                 #将分隔符归一后分割
    try:
        count(raw[0],raw[1])
    except IndexError:
        print('wrong value count!')      #如出现不合要求的输入，报错并跳转到Continue界面
        c = input('Continue? (y/n)')
        continued(c)
        return                           #递归回到这一层之后跳出该函数（防止跳不出栈）

def magic(n):
    '''判断魔法数的主程序'''
    sn = str(n)
    for i in sn:
        if int(i):                       #去除等于零的可能
            if (n % int(i)):
                return 0 
    return 1                             #如为魔法数则为1.反之为0

def continued(c):
    '''判断是否继续'''
    if c == 'y':                         #如果输入y则跳入inputpart重新输入
        inputpart()
    elif c == 'n':                       #输入n则一层一层跳出
        print('Bye....')
        return
    else:
        print('请输入y或n')
        c = input('Continue? (y/n)')     #输入了其他什么奇怪东西的话就再次调用该函数
        continued(c)
        return

def count(a,b):
    '''计算魔法数的个数'''
    js = 0
    try:
        aa = int(a)
        bb = int(b)                      #将输入的字符尝试化为浮点数
    except ValueError:
        print('wrong type!')             #如输入的不是数字则报错并跳出
        c = input('Continue? (y/n)')
        continued(c)
        return
    else:
        if aa > bb:
            print('wrong range')         #如范围错误同样报错跳出
            c = input('Continue? (y/n)')
            continued(c)
            return
        for i in range(aa,bb+1):
            if magic(i):
                js += 1                  #计数
    
        if js == 1:
            print('[%d,%d] has 1 magic number!' %(aa,bb))
        else:
            print('[%d,%d] has %d magic numbers!'%(aa,bb,js))
    c = input('Continue? (y/n)')         #处理单复数并输出
    continued(c)

inputpart()
