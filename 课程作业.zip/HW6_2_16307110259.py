import math
s=[]
for i in range(1,5):
    for j in range(1,5):
        for k in range(1,5):
            for l in range(1,5):
                if (i!=j) and (i!=k) and (i!=l) and (j!=k) and (j!=l) and (k!=l):
                    
                    total = i * 1000 + j * 100 + k *10 +l                    #判断是否符合标准输入                                
                   
                    flag = 1                                       
                    for bcs in range(2,int(math.sqrt(total))+1):
                        if total % bcs == 0:
                            flag = 0                                
                    if flag:
                        s.append(total)                                      #素数判断
print(s)
