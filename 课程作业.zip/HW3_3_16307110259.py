name = input('Please enter your first name:')
print('Hi,',name,'!')#处理名字部分

examgrades = list(eval(input('Please enter your midterm and final exam grades (separated with comma):')))
hgrades = list(eval(input('Enter all your homework grades(separated with comma):')))#输入数据

hgrades.sort()#排序

avehgrades = (hgrades[( len(hgrades) // 2)] + hgrades[( -1-len(hgrades) // 2)]) / 2  #通过中位数正反序和为-1计算中位数
fgrades = 0.2 * examgrades[0] + 0.4 * examgrades[1] + 0.4 * avehgrades #计算总评

print('Your homework grade is: ',avehgrades)
print('Your final grade is: ',fgrades)#输出
