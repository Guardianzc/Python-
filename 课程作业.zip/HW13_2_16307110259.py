def writein():
    num = input('请输入需要创建的句子数目： ')
    while True:        
        try:
            num = int(num)                                #判断这里是否输入了一个数字，这里出现过一个问题：当不用while而是用递归时传递到下一个函数的只是第一层num的值
        except ValueError:
            print('输入有误，重新输入...')
            num = input('请输入需要创建的句子数目： ')
        else:
            break
    return num

speechPartDict = {'adj':'adj','verb':'verb','noun':'noun'} #初始化字典


import random
lines = []
longstr = ''
handler = open('verb.txt')
try:
    lines = handler.readlines()
finally:
    handler.close()
for i in range(len(lines)):
    longstr = longstr + lines[i] + ','
speechPartDict['verb'] = longstr.split(',')
lenverb = len(speechPartDict['verb']) - 2

lines = []
longstr = ''
handler = open('adj.txt')
try:
    lines = handler.readlines()
finally:
    handler.close()
for i in range(len(lines)):
    longstr = longstr + lines[i] + ','
speechPartDict['adj'] = longstr.split(',')
lenadj = len(speechPartDict['adj']) - 2

lines = []
longstr = ''
handler = open('noun.txt')
try:
    lines = handler.readlines()
finally:
    handler.close()
for i in range(len(lines)):
    longstr = longstr + lines[i] + ','
speechPartDict['noun'] = longstr.split(',')
lennoun = len(speechPartDict['noun']) - 2              #从文件中创建字典并得出每一种单词的数量

nums = int(writein())
for i in range(nums):
    a = random.randint(0,lenverb)
    b = random.randint(0,lenadj)
    c = random.randint(0,lennoun)                     #用random函数建构句子(为什么会有奇怪的空格？)
    print('The',speechPartDict['adj'][b],speechPartDict['noun'][c],speechPartDict['verb'][a],'.')
    
