import random

l = [random.randint(1,100) for i in range(50)]

print('50 random integers are: ',l)         #生成随机数列并输出

odd = (i for i in l if i % 2 == 1 )
even = (i for i in l if i % 2 == 0 )        #奇偶分类

odd = list(odd)
even = list(even)                           #将对象化为列表

print('Among them, the odd numbers are: ',odd)
print('And the even numbers are: ',even)     #输出
