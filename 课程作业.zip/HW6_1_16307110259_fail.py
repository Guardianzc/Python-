import os
s = int(input('Enter an integer(<1000):'))    
final = s
ys = []                                       #创建质因数数组    

if 1 < s < 1000:                                  #判断输入是否合乎标准

    while s > 1:                              #这里的while会导致死循环
        
        for j in range(2,s+1):                  #搜索质因数
            if s % j == 0:
                ys.append(j)
                s = s // j
                break                         #寻找到最小的因数之后马上退出
    ys.append(s)                              #最后留下的s也是质因数  
 
    print('%d = %d'%(final,ys[0]),end='')
    for i in range(1,len(ys)):
        print('*%d'%ys[i],end='')             #标准化输出 
else:
    print('超出范围，请重新输入！')           #对不符合标准的输入进行处理
