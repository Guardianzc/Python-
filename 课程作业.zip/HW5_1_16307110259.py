name = input('Please enter your first name: ')
mid, final = eval(input('Please enter your midterm and final exam grades \
(separated with comma): '))
homework = eval(input('Enter all your homework grades(separated with comma): '))
homework = list(homework)            #输入数据

homework.sort()
m = len(homework)//2
hw = homework[m] if m%2 else (homework[m-1]+homework[m])/2
'''if m%2:
    hw = homework[m]
else:
    hw = (homework[m-1]+homework[m])/2'''#判断中位数
final = 0.2*mid+0.4*final+0.4*hw        #计算总分

if 90 <= final <= 100:
    grade = 'A'
elif 85<= final <90:
    grade = 'A-'
elif 82<= final <85:
    grade = 'B+'
elif 78<= final <82:
    grade = 'B'
elif 75<= final <78:
    grade = 'B-'
elif 71<= final <75:
    grade = 'C+'
elif 66<= final <71:
    grade = 'C'
elif 62<= final <66:
    grade = 'C-'
elif 60<= final <62:
    grade = 'D'
elif      final <60:
    grade = 'F'              #通过条件判断语句得到总评
print('Your homework grade is:', hw)
print('Your final grade is:', final,',and the rank is:',grade)#输出数据

