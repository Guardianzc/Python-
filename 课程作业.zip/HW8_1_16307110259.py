s = input('Enter 2 words(separated with a comma): ')

locat = s.find(',')     #找到逗号的位置

a = s[0:locat]         
b = s[locat+1:]         #切片将其分开（只有两个就不用split了）

flag = 1

for i in a:
    if i not in b:
        flag = 0

for i in b:
    if i not in a:
        flag = 0        #对比检查两者是否有特殊字符

if flag :
    print('"%s" and "%s" are analogous words.' %(a,b))
else:
    print('"%s" and "%s" are not analogous words.' %(a,b))
                        #标准化输出
        
