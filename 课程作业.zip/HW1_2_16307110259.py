import math
a,b,x=eval(input('输入两边长及夹角（度）'))
c=math.sqrt(a**2+b**2-2*a*b*math.cos(x*math.pi/180))
print(c)
