for i in range(10,100001):
    s = str(i)
    l = len(s)
                            #穷举所有的数字并转换为字符串形式
    for j in range(len(s)):
        front = int(s[0:j+1])
        back = s[j+1:]
        if back == '':
            back = 0
        else:
            back = int(back)  #对某一个数在任意范围剪切，规避back为空字符串无法int的情况
       
        if ( front + back ) ** 2 == i:
            print(i,'=(',front,'+',back,')**2')#判断符合要求后输出
        
            
    
    
