#filename property.py
1)import os
2)
3)def printfp():
4)    fh = open('sample.txt')
5)    try:
6)        print('file name  :  %s' % fh.name)
7)        print('access mode:  %s' % fh.mode)
8)        print('encoding   :  %s' % fh.encoding)
9)        print('closed     :  %s' % fh.closed)
10)    finally:
11)        fh.close()
#end printfp
12)
13)if __name__=='__main__': 
14)  printfp()
#end if
