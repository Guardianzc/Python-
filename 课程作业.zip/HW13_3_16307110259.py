import tkinter
from tkinter import END, StringVar

def plus():
    global c
    a = E1_text.get()
    b = E2_text.get()
    try:
        c = (a,'+',b,'=',float(a) + float(b))
    except BaseException:
        c = '请输入数字'
    result.delete(0.0, END)
    result.insert(0.0,c)         #不知道怎么做覆盖只能先删除原来的结果
                                 #加法button的函数，这里得用0.0而非0

def inputclear():
    E1.delete(0, END)
    E2.delete(0, END)
    result.delete(0.0, END)     #清空函数，同理Text得用0.0
    
root = tkinter.Tk()
root.title('简单加法器')
root.geometry('640x320')        #主框体的设计

E1_text = StringVar()
E2_text = StringVar()
E1 = tkinter.Entry(root,textvariable = E1_text)
E2 = tkinter.Entry(root,textvariable = E2_text) #用设置StringVar拿到输入的文本

result = tkinter.Text(root,font = 'cambria')
btn1 = tkinter.Button(root,text = '加法', command = plus)
btn2 = tkinter.Button(root,text = '清空', command = inputclear)#功能初始化设计

E1.place(relx=0.1,rely = 0.2,relheight = 0.1, relwidth = 0.3 )
E2.place(relx=0.6,rely = 0.2,relheight = 0.1, relwidth = 0.3 )
btn1.place(relx=0.1,rely = 0.4,relheight = 0.1, relwidth = 0.3 )
btn2.place(relx=0.6,rely = 0.4,relheight = 0.1, relwidth = 0.3 )
result.place(relx=0,rely = 0.6,relheight = 0.5, relwidth = 1 )#调整各组分的位置
root.mainloop()
