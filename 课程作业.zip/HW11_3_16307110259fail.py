def judge(fname):
    '''从文件名判断文件是.py还是.cpp'''
    with open(fname,'r') as f:
        name = f.name
    name = name.split('.')
    if name[1] == 'py':
        bb = 1
    else:
        bb = 0
    return bb                                         #通过split取出扩展名，用bb做标记从而区别处理

def comment(fname,clear):
    '''处理不同类型的文件'''
    with open(fname,'r') as f:
        lines = f.readlines()
    linenum = 1                                       #初始化行号标记

    if clear:
        for line in lines:
            if not(line.startswith('#')):           
                line = [ str(linenum)+')'+line]
                linenum += 1
                with open(fname[:-3]+'_n.py','a+') as f:
                    f.writelines(line)
            else:
                with open(fname[:-3]+'_n.py','a+') as f:
                    f.writelines(line)                 #当扩展名为.py时的处理，通过循环不断判断写入
        
         
    else:
        for line in lines:              
            if not(line.startswith('//')): 
                line = [ str(linenum)+')'+line]
                linenum += 1           
                with open(fname[:-4]+'_n.cpp','a+') as f:
                    f.writelines(line)
            else:
                with open(fname[:-4]+'_n.cpp','a+') as f:
                    f.writelines(line)                #当扩展名为.cpp时的处理，通过循环不断判断写入
       

comment('Goldbach.cpp',judge('Goldbach.cpp'))         #调用函数

