def word(r,n):
    global dic
    l = len(r)
    r = r.lower()
    for i in range(l-n+1):
        s = r[i:i+n:]                                               #切片操作
        bb = 1
        for key in dic:
            if key == s:
                dic[s] += 1
                bb = 0
        if bb:
            dic[s] = 1                                             #判断是否原有索引加一或添加新的索引

        


longstr = ''                                                        #主程序模块  
handler = open('this.txt')                                             #打开文件
try:
    lines = handler.readlines()
    for line in handler.readlines():
        line = line.strip('\n')

finally:
    handler.close()
for i in range(len(lines)):                                             #把每一行的词写到同一行里
    longstr = longstr + lines[i] + ' '
words = longstr.split(' ')                                              #分隔开成为列表
lenwords = len(words)
for i in range(lenwords):
    words[i] = words[i].replace('\n','')
    
dic = {}
bb = 1                                                              #对Input进行判断
while bb:
    n = input('Please enter a number(1<= N<= 5): ')
    try:
        if 1<=int(n)<=5:
            bb = 0
        else:
            print('Wrong value')
    except ValueError:
        print('Wrong type')
n = int(n)        


for i in range(lenwords):                                              #对其中的每一个词分开判断
    word(words[i],n)



dic = sorted(dic.items(),key=lambda item:item[1],reverse = True)
txt = 'freq'+str(n)+'.txt'
handler = open(txt,'w')
try:
    for key,value in dic:
        s = key + ' ' + str(value)                                    #换行输出到文件中
        handler.write(s)
        handler.write('\n')
finally:
    handler.close()
