for i in range(0,101):
    for j in range(0,101-i):
        k = 100 - i - j
        if 5 * i + 3 * j + k / 3 == 100:
            print('cock:',i,',hen:',j,',chicken:',k) #二次循环穷举
        
