import os
def find(name,path):
    if not os.path.isdir(path):
        print('Error:', path,'is not a directory or does not exist.')
        return 2                                            #如为非法路径则抛出错误值返回
    list_dirs = os.walk(path)
    for root,dirs,files in list_dirs:
        for f in files:
            if name == f:
                return 1                                   #遍历，能找到则返回1，不能则返回0
    return 0

p = input('Enter a directory(absolute path): ')
n = input('Enter a file name: ')
if find(n,p)!=2:
    if find(n,p):
        print(n,' is in the directory:', p)
    else:
        print(n,' is not in the directory:', p)               #按函数运行结果输出不同结果
