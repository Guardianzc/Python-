import string
s = input('Please enter a string: ')
counts = {'lowercase' : 0, 'uppercase' : 0 , 'digits' : 0 , 'others' : 0 }

def statistics(s):
    for ch in s:
        if ch in string.ascii_lowercase:
            counts['lowercase'] += 1
        elif ch in string.ascii_uppercase:
            counts['uppercase'] += 1
        elif ch in string.digits:
            counts['digits'] += 1
        else:
            counts['others'] += 1       #定义函数，循环判断字符的种类计入累加器中

statistics(s)                           #运行函数
for key,value in counts.items():
    print(key,' : ',value)                        
