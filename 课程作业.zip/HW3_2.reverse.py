import random
aList = []
for i in range(20):
    aList.append(random.randint(1,100))#运用循环构建序列
print('The original list is: ',aList)#输出初始序列

upList = aList[0:10]
downList = aList[10:20]#截取前十个和后十个

print(downList)
upList.sort()
downList.reverse()#分别排序
print(downList)

allList = upList + downList
print('After sorting, the list is: ',allList)#合并输出

