s=input('word1,word2,word3=')
word1,word2,word3=s.split()
if word1>word2:
   word1,word2=word2,word1
if word1>word3:
   word1,word3=word3,word1
if word2>word3: 
   word2,word3=word3,word2
print(word1,word2,word3)   
