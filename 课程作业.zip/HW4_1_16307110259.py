d1 = {'name':'Mary Jane','gender':'female','employee No.':'01035','age':24}

print('The dict is:',d1) #产生并输出字典

key = input('Enter the key you want to searth: ')

print(d1.get(key,'No such key in the dictionary'))  #查找并输出值
