import string
s = input('Please enter an English paragraph:')
s = s.split() 
                     #分隔句段

i = 0
while i < len(s)-1:
    if s[i].lower() == s[i+1].strip(string.punctuation).lower():
        s.pop(i)
        continue
    else:
        i += 1
                    #处理后一个去标点，处理大小写后是否相同，如相同删去前面的（后面的可能带标点）

print('After deleting consecutive identical words, the paragraph is:')
print(' '.join(s))  #标准化输出
    
