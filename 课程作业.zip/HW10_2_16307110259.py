import random
initialise = [random.randint(1,100) for i in range(10)]  #初始化列表
inittuple = tuple(initialise)


print('The test-tuple is: ',inittuple)

def Sorted(a , reverse = False):          #定义函数Sorted，默认从小到大排序
    '''(模拟内置函数sorted)'''

    global lista
    lista = list(a)
    
    if reverse:                         #从大到小冒泡排序
        for i in range(10):
            x = lista[i]
            for j in range(i,10):
                if x < lista[j]:
                    lista[i] = lista[j]
                    lista[j] = x
                    x        = lista[i] 
    else:                               #从小到大冒泡排序
        for i in range(10):
            x = lista[i]
            for j in range(i,10):
                if x > lista[j]:
                    lista[i] = lista[j]
                    lista[j] = x
                    x        = lista[i]


Sorted(initialise)
print('After calling function Sorted(test_tuple), the returned list is: ',lista)

Sorted(initialise,True)
print('After calling function Sorted(test_tuple,reverse=True), the returned list is: ',lista)






    
