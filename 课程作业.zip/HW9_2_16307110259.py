s = input('Enter an email address: ')
s = s.split('@',1)

user = s[0]
server = s[1]
flag = 1                                        #按照@将其分为用户和服务器两部分


if (user[0].isalnum()) and (user[-1].isalnum()):#判断首尾是否合乎要求
    user = user.replace('-','.')
    user = user.replace('_','.')
    user = user.split('.')                     #因为下划线和连接符都允许输入，于是将其全部替换为‘.’，这样分割后的数据只有字符和数字
    for i in user:
        if not(i.isalpha()):
            flag = 0
                                               #判断是否存在其他非法字符
            
else:
    flag = 0
    

if (server[0].isalnum()) and (server[-1].isalnum()):
    server = server.split('.')
    len1 = len(server[-1])
    len2 = len(server)                         #判断首尾，进行分割
      
    
    if ((len1 != 2) and (len1 != 3)) or (not(server[-1].isalpha())):
        flag = 0                               #判断最后的字符串是否符合要求
        

    for i in range(len2):
        server[i] = server[i].replace('-','0')
        if not(server[i].isalnum()):
            flag = 0                           #将连接符替换成‘0’，之后，合法的输入只应该有字母和数字
            
else:
    flag = 0
    

if flag:
    print('This is a valid email address.')    #判断最后的标记
else:
    print('This is an invalid email address.')
    
    
            
